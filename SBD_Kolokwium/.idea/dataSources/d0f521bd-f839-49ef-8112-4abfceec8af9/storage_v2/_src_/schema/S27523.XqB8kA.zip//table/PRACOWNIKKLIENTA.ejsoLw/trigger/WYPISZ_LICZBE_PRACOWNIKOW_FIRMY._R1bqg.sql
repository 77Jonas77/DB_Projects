create trigger WYPISZ_LICZBE_PRACOWNIKOW_FIRMY
    after insert
    on PRACOWNIKKLIENTA
    for each row
DECLARE
    liczba_pracownikow NUMBER;
BEGIN
    -- Pobierz aktualną liczbę pracowników dla danej firmy
    SELECT COUNT(*)
    INTO liczba_pracownikow
    FROM PracownikKlienta
    WHERE IdFirma = :NEW.IdFirma;

    -- Wypisz liczbę pracowników
    DBMS_OUTPUT.PUT_LINE('Liczba pracowników dla firmy o IdFirma = ' || :NEW.IdFirma || ': ' || liczba_pracownikow);
END;
/

