create PROCEDURE AktualizujBonusowePunkty
    (v_IdFirmy PRACOWNIKKLIENTA.IDFIRMA%type, v_IdSzkolenie WYNIKPRACOWNIKA.IDSZKOLENIE%type, v_Prog1 int, v_Prog2 int)
IS
    v_ctSzkolenie int;
    v_ctSzkolenieZak int;
    v_checkFirma int;

    CURSOR WynPrac IS
    SELECT IDSZKOLENIE, WYNIKPRACOWNIKA.IDPRACOWNIK,
           CASE
               WHEN WYNIK < v_Prog1 THEN NULL
               WHEN WYNIK >= v_Prog1 AND WYNIK < v_Prog2 THEN 5
               ELSE 10
           END
    FROM WYNIKPRACOWNIKA
    INNER JOIN PRACOWNIKKLIENTA ON WYNIKPRACOWNIKA.IDPRACOWNIK = PRACOWNIKKLIENTA.IDPRACOWNIK
    WHERE IDFIRMA = v_IdFirmy AND IDSZKOLENIE = v_IdSzkolenie;

    v_IdPracownika WYNIKPRACOWNIKA.IDPRACOWNIK%TYPE;
    v_IdSzkolenia WYNIKPRACOWNIKA.IDSZKOLENIE%TYPE;
    v_BonusowePunkty WYNIKPRACOWNIKA.WYNIK%TYPE;
    v_aktWynik WYNIKPRACOWNIKA.WYNIK%TYPE;
BEGIN
    SELECT COUNT(*) INTO v_checkFirma FROM FIRMA WHERE IDFIRMA = v_IdFirmy;
    IF v_checkFirma < 1 THEN
        DBMS_OUTPUT.PUT_LINE('Firma o podanym id nie istnieje!');
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_ctSzkolenie FROM SZKOLENIE WHERE IDSZKOLENIE = v_IdSzkolenie;
    IF v_ctSzkolenie < 1 THEN
        DBMS_OUTPUT.PUT_LINE('Szkolenie o podanym id nie istnieje!');
        RETURN;
    END IF;

    IF v_Prog1 = 0 OR  v_Prog2 = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Progi musza byc rozne od 0!');
        RETURN;
    end if;

    IF v_Prog1 = v_Prog2 THEN
        DBMS_OUTPUT.PUT_LINE('Progi musza byc roznej wartosci!');
        RETURN;
    end if;


    SELECT COUNT(*) INTO v_ctSzkolenieZak
    FROM SZKOLENIE
    WHERE IDSZKOLENIE = v_IdSzkolenie AND DATAZAKONCZENIA IS NULL;
    IF v_ctSzkolenieZak > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Dane szkolenie jeszcze się nie zakończyło! Nie można zaktualizować wyników dla tego szkolenia!');
        RETURN;
    END IF;

    OPEN WynPrac;
    LOOP
        FETCH WynPrac INTO v_IdSzkolenia, v_IdPracownika, v_BonusowePunkty;
        EXIT WHEN WynPrac%NotFound;

        SELECT WYNIK INTO v_aktWynik FROM WYNIKPRACOWNIKA WHERE IDPRACOWNIK = v_IdPracownika AND IDSZKOLENIE = v_IdSzkolenia;
        v_aktWynik := v_aktWynik + NVL(v_BonusowePunkty, 0);

        UPDATE WYNIKPRACOWNIKA
        SET WYNIK = v_aktWynik
        WHERE IDSZKOLENIE = v_IdSzkolenia AND IDPRACOWNIK = v_IdPracownika;

        DBMS_OUTPUT.PUT_LINE('Wynik pracownika o id: ' || v_IdPracownika || ' został zmieniony na: ' || v_aktWynik);
    END LOOP;
    CLOSE WynPrac;

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20006, 'Błąd podczas aktualizacji bonusowych punktów: ' || SQLERRM);
END;
/

