create trigger USUN_SZKOLENIA_PRZED_USUNIECIEM_TRENERA
    before delete
    on TRENER
    for each row
BEGIN
    UPDATE Szkolenie SET IdTrener = NULL WHERE IdTrener = :OLD.IdTrener;

    UPDATE WynikPracownika SET IdPracownik = NULL WHERE IdPracownik = :OLD.IdTrener;

    DELETE FROM SpecjalizacjaTrenera WHERE SpecjalizacjaTrenera.IdTrener = :OLD.IdTrener;
END;
/

