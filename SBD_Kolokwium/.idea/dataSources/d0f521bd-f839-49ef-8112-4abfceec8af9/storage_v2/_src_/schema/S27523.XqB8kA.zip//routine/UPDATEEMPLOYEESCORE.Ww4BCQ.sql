create PROCEDURE UpdateEmployeeScore
    (v_IdPracownika WYNIKPRACOWNIKA.IDPRACOWNIK%type, v_IdSzkolenie WYNIKPRACOWNIKA.IDSZKOLENIE%type, v_Wynik WYNIKPRACOWNIKA.WYNIK%type)
IS
    v_ctPracownik int;
    v_ctSzkolenie int;
    v_ctSzkolenieTrwa int;
    v_aktWynik int;
BEGIN
    SELECT COUNT(*) INTO v_ctPracownik FROM PRACOWNIKKLIENTA WHERE IDPRACOWNIK=v_IdPracownika;
    IF v_ctPracownik < 1 THEN
        DBMS_OUTPUT.PUT_LINE('Pracownik o podanym id nie istnieje!');
        RETURN;
    end if;

    SELECT COUNT(*) INTO v_ctSzkolenie FROM SZKOLENIE WHERE IDSZKOLENIE=v_IdSzkolenie;
    IF v_ctSzkolenie < 1 THEN
        DBMS_OUTPUT.PUT_LINE('Szkolenie o podanym id nie istnieje!');
        RETURN;
    end if;

    SELECT COUNT(*) INTO v_ctSzkolenieTrwa
    FROM SZKOLENIE
    WHERE IDSZKOLENIE=v_IdSzkolenie AND DATAZAKONCZENIA IS NOT NULL; --NOT
    IF v_ctSzkolenieTrwa > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Dane szkolenie juz sie zakonczylo! Nie mozna zaktualizowac wynikow dla tego szkolenia!');
        RETURN;
    end if;

    SELECT CASE
               WHEN WYNIK IS NOT NULL THEN WYNIK
               ELSE 0
               END
    INTO v_aktWynik
    FROM WYNIKPRACOWNIKA
    WHERE IDSZKOLENIE = v_IdSzkolenie AND IDPRACOWNIK = v_IdPracownika;

    IF v_aktWynik > v_Wynik THEN
        DBMS_OUTPUT.PUT_LINE('Nie mozna wprowadzic wyniku wiekszego niz 100, poniewaz operujemy na skali 0-100%!');
        RETURN;
    end if;


    IF v_Wynik > 100 THEN
        DBMS_OUTPUT.PUT_LINE('Nie mozna wprowadzic wyniku wiekszego niz 100, poniewaz operujemy na skali 0-100%!');
        RETURN;
    end if;

    --generalnie wszystko idzie chyba wykonac w jednym update i warunkami w WHERE, ale ogranicza to nam ilosc precyzyjnych komunikatow dla blednych inputow
    UPDATE WYNIKPRACOWNIKA
    SET WYNIK = v_Wynik
    WHERE IDPRACOWNIK = v_IdPracownika AND IDSZKOLENIE=v_IdSzkolenie;

EXCEPTION
--RAISE_APPLICATION_ERROR(error_code, error_message) --> SQLERRM -> zwraca nam bardziej szczegolowy komunikat uzyskanego bledu;
    WHEN DUP_VAL_ON_INDEX THEN
        RAISE_APPLICATION_ERROR(-20003, 'Naruszono wiezy spójności!');
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Brak danych dla podanych warunków. Prawdopodobnie dany pracownik nie bierze udzialu w tym szkoleniu');
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20004, 'Nieznany błąd: ' || SQLERRM);
END;
/

