create trigger LICZ_PRACOWNIKOW
    after insert or delete
    on PRACOWNIKKLIENTA
DECLARE
    liczba_pracownikow NUMBER;
BEGIN
    SELECT COUNT(*) INTO liczba_pracownikow FROM PracownikKlienta;
    DBMS_OUTPUT.PUT_LINE('Liczba pracowników w firmie: ' || liczba_pracownikow);
END;
/

