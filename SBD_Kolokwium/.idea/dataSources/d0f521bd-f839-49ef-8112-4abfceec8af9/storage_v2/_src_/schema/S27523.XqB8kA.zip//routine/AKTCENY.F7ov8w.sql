create PROCEDURE AktCeny
    (v_podw T_Produkt.cena%type)
IS
BEGIN

end;
/

