create trigger WYPISZ_LICZBE_UCZESTNIKOW
    after insert or delete
    on WYNIKPRACOWNIKA
    for each row
DECLARE
    liczba_uczestnikow NUMBER;
BEGIN
    -- Pobierz aktualną liczbę uczestników dla danego szkolenia
    SELECT COUNT(*)
    INTO liczba_uczestnikow
    FROM WynikPracownika
    WHERE IdSzkolenie = :NEW.IdSzkolenie;

    -- Wypisz liczbę uczestników
    DBMS_OUTPUT.PUT_LINE('Liczba uczestników dla szkolenia o IdSzkolenie = ' || :NEW.IdSzkolenie || ': ' || liczba_uczestnikow);
END;
/

