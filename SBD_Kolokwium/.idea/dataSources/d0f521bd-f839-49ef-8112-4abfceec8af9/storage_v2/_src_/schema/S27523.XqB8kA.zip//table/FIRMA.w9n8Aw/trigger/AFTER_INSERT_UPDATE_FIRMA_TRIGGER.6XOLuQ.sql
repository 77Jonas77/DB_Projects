create trigger AFTER_INSERT_UPDATE_FIRMA_TRIGGER
    after insert or update
    on FIRMA
    for each row
DECLARE
  v_count NUMBER;
BEGIN
  SELECT COUNT(*)
  INTO v_count
  FROM Firma
  WHERE Nazwa = NEW.Nazwa AND IdFirma != NEW.IdFirma;

  IF v_count > 0 THEN
    RAISE_APPLICATION_ERROR(-20003, 'Firma o podanej nazwie już istnieje!');
    ROLLBACK;
  END IF;

  SELECT COUNT(*)
  INTO v_count
  FROM Firma
  WHERE NIP = NEW.NIP AND IdFirma != NEW.IdFirma;

  IF v_count > 0 THEN
    RAISE_APPLICATION_ERROR(-20004, 'Firma o podanym NIP już istnieje!');
    ROLLBACK;
  END IF;
END;
/

