create PROCEDURE ObslugaZwolnieniaTrenera
    (v_IdTrenera Trener.IDTRENER%type)
IS
    CURSOR SzkoleniaTreneraCur IS
        SELECT IDSZKOLENIE
        FROM SZKOLENIE
        WHERE IDTRENER = v_IdTrenera AND DataZakonczenia IS NULL;
    v_cntTrener int;
    v_dataZak date;
    v_IdSzkolenia SZKOLENIE.IDSZKOLENIE%TYPE;
BEGIN
    SELECT COUNT(*) INTO v_cntTrener FROM TRENER WHERE IDTRENER = v_IdTrenera;
    IF v_cntTrener < 1 THEN
        DBMS_OUTPUT.PUT_LINE('Trener o podanym id nie istnieje!');
        RETURN;
    end if;

    SELECT DATAZAKONCZENIAWSPOLPRACY INTO v_dataZak FROM TRENER WHERE IDTRENER = v_IdTrenera;
    IF v_dataZak IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('Trener o podanym id juz nie jest zatrudniony!');
        RETURN;
    end if;

    UPDATE Trener
    SET DataZakonczeniaWspolpracy = SYSDATE
    WHERE IDTRENER = v_IdTrenera;

    FOR SzkolenieRec IN SzkoleniaTreneraCur
    LOOP
        v_IdSzkolenia := SzkolenieRec.IDSZKOLENIE;

        UPDATE SZKOLENIE
        SET DataZakonczenia = SYSDATE
        WHERE IDSZKOLENIE = v_IdSzkolenia;
    END LOOP;

    --UPDATE SZKOLENIE
    --SET DataZakonczenia = SYSDATE
    --WHERE IDTRENER = v_IdTrenera AND DataZakonczenia IS NULL;

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20005, 'Błąd podczas obsługi zwolnienia trenera: ' || SQLERRM);
END;
/

