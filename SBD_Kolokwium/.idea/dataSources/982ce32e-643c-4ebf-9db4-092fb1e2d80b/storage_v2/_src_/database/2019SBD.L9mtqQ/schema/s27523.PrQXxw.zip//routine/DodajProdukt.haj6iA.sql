CREATE PROCEDURE DodajProdukt @Nazwa VARCHAR(50), @Cena MONEY, @Kategoria INT
AS
BEGIN
    IF @Nazwa IN (SELECT Nazwa FROM T_Produkt)
        PRINT N'Produkt o takiej nazwie już istnieje. Nie wprowadzono żadnych zmian do tabeli.';
    ELSE
        IF @Kategoria NOT IN (SELECT Id FROM T_Kategoria)
            PRINT N'Podana kategoria nie istnieje, produkt nie został dodany';
        ELSE
            BEGIN
                INSERT INTO T_Produkt VALUES ((SELECT MAX(Id) + 1 FROM T_Produkt), @Nazwa, @Cena, @Kategoria);
                PRINT N'Pomyślnie dodano nowy produkt'
            END
END
go

