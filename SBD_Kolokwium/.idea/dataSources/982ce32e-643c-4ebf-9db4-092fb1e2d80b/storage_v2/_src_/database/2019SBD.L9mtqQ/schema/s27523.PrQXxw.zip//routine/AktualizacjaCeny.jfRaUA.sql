CREATE PROCEDURE AktualizacjaCeny @PlusPrice float = 0.01
AS 
BEGIN 
SET NOCOUNT ON;
UPDATE T_PRODUKT SET cena = cena + @PlusPrice;
PRINT 'Liczba zaktualizowanych rekordow: ' + CAST(@@ROWCOUNT AS Varchar(5));
END
go

