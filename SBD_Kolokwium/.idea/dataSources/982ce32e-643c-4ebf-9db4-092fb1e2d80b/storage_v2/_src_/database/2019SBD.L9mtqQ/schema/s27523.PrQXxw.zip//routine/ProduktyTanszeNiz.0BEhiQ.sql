CREATE PROCEDURE ProduktyTanszeNiz @MaxPrice int
AS 
BEGIN 
 SELECT p.Nazwa, p.Cena
 FROM T_PRODUKT p
 WHERE Cena < @MaxPrice;
 END

 EXEC ProduktyTanszeNiz 2.0;
go

