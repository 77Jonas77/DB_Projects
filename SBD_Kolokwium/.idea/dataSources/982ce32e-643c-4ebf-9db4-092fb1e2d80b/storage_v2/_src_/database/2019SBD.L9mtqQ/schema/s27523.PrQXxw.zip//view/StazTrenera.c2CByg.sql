--F. MIN nie wymusza dodania kolumny do grupowania
        CREATE VIEW StazTrenera(Trener, Staz)
        AS
            SELECT IdTrener, DATEDIFF(MONTH, MIN(DataZatrudnienia), GETDATE())
            FROM Trener
            WHERE DataZakonczeniaWspolpracy IS NULL
            GROUP BY IdTrener
go

