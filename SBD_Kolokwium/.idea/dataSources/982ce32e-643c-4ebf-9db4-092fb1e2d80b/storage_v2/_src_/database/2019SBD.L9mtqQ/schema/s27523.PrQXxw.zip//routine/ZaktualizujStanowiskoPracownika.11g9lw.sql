CREATE PROCEDURE ZaktualizujStanowiskoPracownika @IdPracownika int, @IdStanowiska int
                        AS
                        BEGIN
                            SET NOCOUNT ON;
                            IF (@IdPracownika) NOT IN (SELECT T_Pracownik.ID FROM T_Pracownik) OR
                               (@IdStanowiska) NOT IN (SELECT T_Stanowisko.Id FROM T_Stanowisko)
                                PRINT 'Podano nieprawidlowe dane';
                            ELSE
                                IF @IdStanowiska IN (SELECT z.Stanowisko
                                                     FROM T_Zatrudnienie z
                                                     WHERE z.Pracownik = @IdPracownika
                                                       AND z.Do IS NULL)
                                    PRINT N'Pracownik jest już przypisany na to stanowisko';
                                ELSE
                                    IF (CAST(GETDATE() AS DATE) IN (SELECT T_Zatrudnienie.DO
                                                                    FROM T_Zatrudnienie
                                                                    WHERE Pracownik = @IdPracownika
                                                                      AND T_Zatrudnienie.DO is not null
                                                                      AND T_Zatrudnienie.Stanowisko = @IdStanowiska))
                                        PRINT N'Zmiany nie zostały zapisane, stanowisko można aktualizować tylko raz dziennie';
                                    ELSE
                                        BEGIN
                                            UPDATE T_Zatrudnienie
                                            SET Do = GETDATE()
                                            WHERE Pracownik = @IdPracownika
                                              AND Do IS NULL;
                                            INSERT INTO T_Zatrudnienie
                                            VALUES (@IdPracownika, @IdStanowiska, GETDATE(), NULL);
                                            PRINT N'Pomyślnie zaktualizowano stanowisko pracownika';
                                        end
                        end
go

