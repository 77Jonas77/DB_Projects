CREATE PROCEDURE zad1 @Imie varchar(50), @NazwaZawodow varchar(50)
AS
    BEGIN
    SET NOCOUNT ON;
    DECLARE @IdZaw int, @IdZawodow int, @Runda int;
    SELECT @IdZawodow = Id from K9_Zawody WHERE NAZWA = @NazwaZawodow;
    SELECT @IdZaw = Id from K9_Zawodnik WHERE Imie = @Imie;
        IF(@Imie not in(select Imie from K9_Zawodnik))
            BEGIN
                INSERT INTO K9_Zawodnik(Imie) VALUES (@Imie);
                PRINT 'Zawodnik nie istnieje';
                SELECT @IdZaw = @@identity;
            end
        ELSE
            PRINT 'Zawodnik istnieje';
        IF(NOT EXISTS(SELECT Runda FROM K9_Udzial INNER JOIN K9_Zawody on K9_Udzial.Zawody = K9_Zawody.Id WHERE K9_Zawody.Nazwa = @NazwaZawodow))
            begin
                INSERT INTO K9_Udzial(Zawodnik, Zawody, Runda, Punkty) VALUES (@IdZaw,@IdZawodow,1,0);
                PRINT 'Nie ma rund';
            end
        ELSE
            BEGIN
               SELECT @Runda = MAX(Runda) + 1 FROM K9_Udzial INNER JOIN K9_Zawody K9Z on K9_Udzial.Zawody = K9Z.Id WHERE K9Z.Nazwa = @NazwaZawodow;
               INSERT INTO K9_Udzial(Zawodnik, Zawody, Runda, Punkty) VALUES (@IdZaw, @IdZawodow, @Runda, 0);
            end;
        END
go

