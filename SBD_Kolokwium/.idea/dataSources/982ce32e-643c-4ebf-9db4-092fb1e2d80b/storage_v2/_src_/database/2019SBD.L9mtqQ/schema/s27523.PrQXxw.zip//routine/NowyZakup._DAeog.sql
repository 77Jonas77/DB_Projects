CREATE PROCEDURE NowyZakup @IdKlient int, @Zakup int OUTPUT
AS 
BEGIN 
INSERT INTO T_ZAKUP (Data, Klient) VALUES (GETDATE(), @IdKlient);
SET @Zakup = @@IDENTITY;
PRINT 'Zarejestrowano nowy zakup o id : ' + CAST(@Zakup AS Varchar(5));
END
go

