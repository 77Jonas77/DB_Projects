CREATE PROCEDURE zmiana_ceny @WartoscDolna money, @WartoscGorna money
AS
BEGIN
SET NOCOUNT ON;
DECLARE
moj_kursor CURSOR FOR
SELECT nazwa,
       CASE
           WHEN cena < @WartoscDolna THEN ROUND(cena + (cena * 0.05), 2)
           WHEN cena > @WartoscGorna THEN ROUND(cena - (cena * 0.1), 2)
           ELSE cena
           END
FROM T_Produkt
WHERE cena NOT BETWEEN @WartoscDolna AND @WartoscGorna;

DECLARE
@Nazwa Varchar(30), @Cena money;

OPEN moj_kursor;
FETCH NEXT FROM moj_kursor INTO @Nazwa, @Cena;
WHILE
@@Fetch_status = 0
BEGIN
    UPDATE T_Produkt
    SET cena = @Cena
    WHERE nazwa = @Nazwa;
    PRINT
    ('Cena ' + @Nazwa + ' została zmieniona na: ' + CAST(@Cena AS Varchar(5)) +'$.')
FETCH NEXT FROM moj_kursor INTO @Nazwa, @Cena;
END;
CLOSE moj_kursor;
DEALLOCATE
moj_kursor;
END;
EXEC zmiana_ceny 1, 2;
go

