CREATE PROCEDURE DanePracownika @IdPracownik int, @Imie VARCHAR(30) OUTPUT, @Nazwisko VARCHAR(30) OUTPUT
                AS
                BEGIN
                    IF @IdPracownik not in (select T_Pracownik.Id from T_Pracownik)
                        PRINT 'Pracownik o podanym id nie istnieje';
                    ELSE
                        BEGIN
                            SET @Imie = (SELECT Imie FROM T_Osoba WHERE Id = @IdPracownik);
                            SET @Nazwisko = (SELECT Nazwisko FROM T_Osoba WHERE Id = @IdPracownik);
                            PRINT 'Dane: ' + @Imie + '_' + @Nazwisko;
                        END
                end
go

