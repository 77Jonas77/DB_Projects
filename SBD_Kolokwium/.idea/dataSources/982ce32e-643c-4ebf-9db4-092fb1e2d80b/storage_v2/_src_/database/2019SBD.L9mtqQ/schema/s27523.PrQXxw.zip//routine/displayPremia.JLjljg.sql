CREATE PROCEDURE displayPremia @IloscMiesiecy int
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @IdTrenera int, @Staz int, @Premia numeric(8,2), @IloscSzkolen int;

    DECLARE premia_trenera CURSOR FOR
    SELECT IdTrener, DATEDIFF(MONTH, MIN(DataZatrudnienia), GETDATE()) AS Staz
    FROM Trener
    WHERE DataZakonczeniaWspolpracy IS NULL
    GROUP BY IdTrener;

    OPEN premia_trenera;
    FETCH NEXT FROM premia_trenera INTO @IdTrenera, @Staz;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @Staz < @IloscMiesiecy
            PRINT 'Trener o id: ' + CAST(@IdTrenera AS VARCHAR(5)) + ' nie otrzymuje premii';
        ELSE
        BEGIN
            SELECT @IloscSzkolen = COUNT(IdSzkolenie)
            FROM Szkolenie
            INNER JOIN Trener ON Szkolenie.IdTrener = Trener.IdTrener
            WHERE Trener.IdTrener = @IdTrenera AND DataZakonczenia IS NOT NULL;

            SELECT @Premia = ROUND((Wynagrodzenie/100)*@Staz+@IloscSzkolen*100,2)
            FROM Trener
            WHERE IdTrener = @IdTrenera;
            PRINT 'Trener o id: ' + CAST(@IdTrenera AS VARCHAR(5)) + N' otrzymuje premie w wysokości: ' + CAST(@Premia AS VARCHAR(10));
        END;

        FETCH NEXT FROM premia_trenera INTO @IdTrenera, @Staz;
    END;

    CLOSE premia_trenera;
    DEALLOCATE premia_trenera;
END;
go

