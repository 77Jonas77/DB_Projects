CREATE TRIGGER TR_Szkolenie_Update
    ON Szkolenie
    FOR UPDATE, INSERT
    AS
    BEGIN
        DECLARE @IdSzkolenie int, @IdRodzaj int, @IdTrener int, @DataRoz date, @DataZak date;
        SELECT @IdSzkolenie = IdSzkolenie, @IdRodzaj=IdRodzaj, @IdTrener=IdTrener, @DataRoz=DataRozpoczecia, @DataZak=DataZakonczenia FROM inserted;
        IF(@DataRoz>@DataZak)
            BEGIN
                RAISERROR('DataZakonczenia nie moze byc mniejsza niz DataRozpoczecia! Zmiany nie zostaly zapisane!',16,1);
                ROLLBACK;
            end
        IF @DataRoz < ANY(SELECT DataRozpoczecia FROM Szkolenie WHERE IdTrener=@IdTrener)
            BEGIN
                RAISERROR('Nie mozna wprowadzic daty rozpoczynajacej wczesniejszej od innych rozpoczynajacych! Zmiany nie zostaly zapisane!',16,1);
                ROLLBACK;
            end
    end;
go

