CREATE PROCEDURE assignPracownikToSzkolenie @IdPracownika int, @IdSzkolenia int
    AS
        BEGIN
            IF @IdPracownika NOT IN (SELECT IdPracownik FROM PracownikKlienta)
                PRINT 'Pracownik o podanym id nie istnieje';
            ELSE IF @IdSzkolenia NOT IN (SELECT IdSzkolenie FROM Szkolenie)
                PRINT 'Szkolenie o podanym id nie istnieje';
            ELSE IF(SELECT DataZakonczenia FROM Szkolenie WHERE IdSzkolenie = @IdSzkolenia) IS NOT NULL
                PRINT 'Szkolenie o podanym id juz sie zakonczylo!';
            ELSE IF @IdSzkolenia IN (SELECT WynikPracownika.IdSzkolenie FROM WynikPracownika INNER JOIN Szkolenie ON WynikPracownika.IdSzkolenie = Szkolenie.IdSzkolenie
                                     WHERE IdPracownik = @IdPracownika AND DataZakonczenia IS NULL)
                PRINT 'Pracownik jest juz przypisany do podanego szkolenia!';
            ELSE
                BEGIN
                    INSERT INTO WynikPracownika(IdSzkolenie, IdPracownik, Wynik) VALUES (@IdPracownika,@IdSzkolenia,NULL);
                    PRINT 'Pracownik o id: ' + CAST(@IdPracownika AS VARCHAR(5)) + 'zostal pomyslnie przypisany do szkolenia o id: ' + CAST(@IdSzkolenia AS VARCHAR(5));
                END;
        END;
go

