CREATE PROCEDURE DodajProduktDoZakupu @Produkt int, @Ilosc int, @Zakup int OUTPUT
    AS
    BEGIN
        IF @PRODUKT NOT IN (SELECT ID FROM T_PRODUKT) OR @Zakup NOT IN (SELECT ID FROM T_ZAKUP) or @Ilosc <= 0
            PRINT 'Nieprawidlowe dane';
        ELSE
            BEGIN
            INSERT INTO T_ListaProduktow(Zakup, Produkt, Ilosc) values (@Zakup, @Produkt, @Zakup);
            PRINT 'Do zakupu ' + CAST(@Zakup AS VARCHAR(5))
                + ' dodano produkt ' + CAST(@Produkt AS VARCHAR(5))
                + N', w ilości: ' + CAST(@Ilosc AS VARCHAR(5));
            END
    END
go

