CREATE PROCEDURE NewPurcharse @IdKlienta int, @IdZakup int OUTPUT
AS
    BEGIN
        INSERT INTO T_Zakup (Data, Klient) VALUES (GETDATE(), @IdKlienta);
        SET @IdZakup = @@identity;
        PRINT 'Zarejstrowano zakup o id: ' + CAST(@IdZakup AS VARCHAR(5));
    end;

DECLARE @ZakupId int;
go

