CREATE TRIGGER TR_Osoba_Insert
    ON Osoba
    INSTEAD OF INSERT
    AS
        BEGIN
            DECLARE @Id int, @Pesel char(11), @NrTel varchar(20), @Imie varchar(30), @Nazwisko varchar(30), @KrajPochodzenia varchar(30);
            SELECT @Id = IdOsoba, @Pesel = Pesel, @NrTel = NrTelefonu, @Imie = Imie, @Nazwisko = Nazwisko, @KrajPochodzenia = KrajPochodzenia FROM inserted;
            IF @Pesel IN (SELECT PESEL FROM Osoba)
                BEGIN
                    RAISERROR ('Osoba o takim nr PESEL juz istnieje! Rekord nie zostal dodany!',16,1);
                end
            ELSE IF @NrTel IN (SELECT NrTelefonu FROM Osoba)
                BEGIN
                    RAISERROR ('Osoba o takim nr telefonu juz istnieje! Rekord nie zostal dodany!',16,1);
                end
            ELSE
            BEGIN
                INSERT INTO Osoba(IdOsoba,PESEL,Imie, Nazwisko,NrTelefonu,KrajPochodzenia) VALUES (@Id,@Pesel,@NrTel,@Imie,@Nazwisko,@KrajPochodzenia);
                PRINT 'Pomyslnie dodano osobe o PESELu: ' + @Pesel + ' i nr telefonu: ' + @NrTel;
            end;
        end;
go

