CREATE TRIGGER TR_WynikPracownika
    ON WynikPracownika
    FOR INSERT
        AS
            BEGIN
                DECLARE @Wynik int, @IdSzkolenia int, @IdPracownika int;
                SELECT @Wynik = Wynik, @IdSzkolenia = IdSzkolenie, @IdPracownika = IdPracownik from inserted;
                IF @Wynik IS NOT NULL
                    BEGIN
                        RAISERROR('Nie mozna recznie wpisac wartosci dla "Wynik", rekord nie zostal dodany',16,1);
                        ROLLBACK;
                    end
                ELSE
                    PRINT 'Pomyslnie dodano pracownika o id: ' + CAST(@IdPracownika AS VARCHAR(5)) + ' do szkolenia o id: ' + CAST(@IdSzkolenia AS VARCHAR(5));
            END;
go

