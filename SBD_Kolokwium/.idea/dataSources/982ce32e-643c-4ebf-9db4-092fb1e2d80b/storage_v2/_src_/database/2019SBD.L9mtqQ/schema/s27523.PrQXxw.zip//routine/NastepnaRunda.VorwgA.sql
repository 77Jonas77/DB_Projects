CREATE PROCEDURE NastepnaRunda @NazwaZawodow varchar(50)
    AS
    BEGIN
        IF (EXISTS(SELECT 1
                   FROM K9_Udzial
                            INNER JOIN K9_Zawody K on K9_Udzial.Zawody = K.Id
                   WHERE K.Nazwa = @NazwaZawodow
                     and K9_Udzial.Punkty = 0))
            PRINT N'Aktualna runda jeszcze się nie zakończyła';
        ELSE
            BEGIN
                DECLARE @IdZawody int;
                SELECT @IdZawody = Id FROM K9_Zawody WHERE Nazwa = @NazwaZawodow;
                DECLARE zawodnicy CURSOR for
                    SELECT Zawodnik, Punkty
                    FROM K9_Udzial
                             INNER JOIN K9_Zawody Z on K9_Udzial.Zawody = Z.Id
                    WHERE Z.Nazwa = @NazwaZawodow;

                open zawodnicy;
                DECLARE @IdZawod int, @Punkty int;
                FETCH NEXT FROM zawodnicy INTO @IdZawod, @Punkty;
                DECLARE @MinWyn int , @MaxRunda int;
                SELECT @MaxRunda = max(Runda)
                               from K9_Udzial
                                        inner join K9_Zawody on K9_Udzial.Zawody = K9_Zawody.Id
                               where K9_Zawody.Nazwa = @NazwaZawodow
                SELECT @MinWyn = min(Punkty)
                from K9_udzial
                         inner join K9_Zawody on K9_Udzial.Zawody = K9_Zawody.Id
                where K9_Zawody.Nazwa = @NazwaZawodow
                  AND Runda = @MaxRunda;
                WHILE @@FETCH_STATUS = 0
                    begin
                        IF (@Punkty <> @MinWyn)
                            INSERT INTO K9_Udzial(Zawodnik, Zawody, Runda, Punkty) VALUES (@IdZawod, @IdZawody, @MaxRunda+1,0);
                        FETCH NEXT FROM zawodnicy INTO @IdZawod, @Punkty;
                    end
                close zawodnicy;
                deallocate zawodnicy;
            END
    END;
go

